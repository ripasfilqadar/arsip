<?php
class M_Karyawan extends MY_Model
{
  public $table = 'karyawan';
  function __construct()
	{
      parent::__construct();
  }
}

?>

<?php
class Attachment extends BaseModel
{
  public $table = 'attachment';
  function __construct()
	{
      parent::__construct();
	}
}

?>
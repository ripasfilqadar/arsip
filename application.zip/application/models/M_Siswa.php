<?php
class M_Siswa extends MY_Model
{
  public $table = 'siswa';
  function __construct()
	{
      parent::__construct();
  }
}

?>

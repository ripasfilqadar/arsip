<?php
class M_Laporan extends MY_Model
{
  public $table = 'laporan';
  function __construct()
	{
      parent::__construct();
  }
}

?>

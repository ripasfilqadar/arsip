<?php

class M_surat_keluar extends MY_Model
{
  public $table = 'surat_keluar';
  function __construct() {
		parent::__construct();
	}
}

?>

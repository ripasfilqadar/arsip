<?php

class M_surat_masuk extends MY_Model
{
  public $table = 'surat_masuk';
  function __construct() {
		parent::__construct();
	}
}

?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
<!--   <section class="content-header">
    <h1>
      Surat Tugas
      <small>Pencacahan</small>
    </h1>
  </section> -->

  <!-- Main content -->
  <section class="content">

    <div class="row">
      <div class="col-md-12">
        <div class="login-logo">
          <p style="font-size: 14pt"><b>Sistem Pencatatan Kearsipan </b></p>
        </div>
      </div><!-- /.col (left) -->
    </div><!-- /.row -->

  </section><!-- /.content -->
</div><!-- /.content-wrapper -->
